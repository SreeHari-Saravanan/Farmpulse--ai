from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Homepage
    path('room/', views.chat_room, name='chat_room'),  # Room handler
]
