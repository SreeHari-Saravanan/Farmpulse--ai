from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

from django.http import HttpResponseNotFound
from django.shortcuts import render

def chat_room(request):
    room_name = request.GET.get('room_name')  # Fetch room name from query parameter
    if not room_name:
        return HttpResponseNotFound("Room name not provided!")
    return render(request, 'room.html', {'room_name': room_name})

